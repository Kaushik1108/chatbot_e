package com.kaushik.chatbot_e.data

data class Message(val message: String, val id: String, val time: String) {
}